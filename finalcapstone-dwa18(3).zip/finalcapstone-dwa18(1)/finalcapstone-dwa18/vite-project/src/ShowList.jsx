import { useState, useEffect } from 'react';

const ShowList = () => {
  const [shows, setShows] = useState([]);
  const [selectedShow, setSelectedShow] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [sortOrder, setSortOrder] = useState('asc'); // 'asc' or 'desc'
  const [displayFavorites, setDisplayFavorites] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://podcast-api.netlify.app/shows');
        if (!response.ok) {
          throw new Error('Network response was not ok.');
        }
        const data = await response.json();
        setShows(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleShowDetails = (show) => {
    setSelectedShow(selectedShow === show ? null : show);
  };

  const handleFavoriteToggle = (show) => {
    const isFavorite = favorites.some((fav) => fav.id === show.id);
    if (isFavorite) {
      setFavorites(favorites.filter((fav) => fav.id !== show.id));
    } else {
      setFavorites([...favorites, show]);
    }
  };

  const handleSort = (order) => {
    setSortOrder(order);
  };

  const handleDisplayFavorites = () => {
    setDisplayFavorites(!displayFavorites);
    setSelectedShow(null);
  };

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const searchFilter = (show) => {
    return show.title.toLowerCase().includes(searchTerm.toLowerCase());
  };

  const favoriteShows = displayFavorites ? favorites : shows;

  const filteredShows = favoriteShows.filter(searchFilter);

  const sortedShows = filteredShows.sort((a, b) => {
    const dateA = new Date(a.updated).getTime();
    const dateB = new Date(b.updated).getTime();
    return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
  });

  return (
    <div className="show-list-container">
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <div className="show-controls">
            <input
              type="text"
              placeholder="Search shows..."
              value={searchTerm}
              onChange={handleSearch}
            />
            <button onClick={() => handleSort('asc')}>Sort A-Z</button>
            <button onClick={() => handleSort('desc')}>Sort Z-A</button>
            <button onClick={() => handleSort(sortOrder === 'asc' ? 'desc' : 'asc')}>
              Sort by Date {sortOrder === 'asc' ? '↑' : '↓'}
            </button>
            <button onClick={handleDisplayFavorites}>
              Favorites <span>({favorites.length})</span>
            </button>
          </div>

          {selectedShow ? (
            <div className="show-details">
              <button onClick={() => setSelectedShow(null)}>Go Back</button>
              <h3>{selectedShow.title}</h3>
              <p>ID: {selectedShow.id}</p>
              <p>Description: {selectedShow.description.substring(0, 100)}</p>
              <p>Seasons: {selectedShow.seasons}</p>
              <p>Episodes: {selectedShow.episodes}</p>
              <p>Updated: {selectedShow.updated}</p>
              <img src={selectedShow.image} alt={selectedShow.title} />
            </div>
          ) : (
            <div className="show-blocks">
              {sortedShows.map((show) => (
                <div key={show.id} className="show-item">
                  <img
                    src={show.image}
                    alt={show.title}
                    onClick={() => handleShowDetails(show)}
                  />
                  <button onClick={() => handleFavoriteToggle(show)}>
                    {favorites.some((fav) => fav.id === show.id) ? '❤️' : '🤍'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ShowList;
