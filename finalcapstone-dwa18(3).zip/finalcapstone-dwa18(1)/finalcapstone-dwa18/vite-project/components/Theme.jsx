import React, { useState, useEffect } from 'react';

const DayNightMode = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  useEffect(() => {
    const body = document.body;
    if (isDarkMode) {
      body.classList.add('dark-theme');
    } else {
      body.classList.remove('dark-theme');
    }
  }, [isDarkMode]);

  return (
    <div className="day-night-mode">
      <button onClick={toggleDarkMode}>
      {isDarkMode ? 'Switch to Day Mode' : 'Switch to Night Mode'}

      </button>
    </div>
  );
};

export default DayNightMode;
