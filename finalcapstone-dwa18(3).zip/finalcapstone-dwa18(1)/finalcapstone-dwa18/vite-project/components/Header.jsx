import React from "react"

export default function Header() {
    return (
        <header className="header">
            <img 
                src="https://rachelcorbett.com.au/wp-content/uploads/2018/07/How-to-design-a-great-podcast-logo.jpg" 
                className="header--image"
            />
            <h2 className="header--title">podcast</h2>
            
        </header>
    )
}