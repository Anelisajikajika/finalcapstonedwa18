import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import React from 'react'
import './index.css'
import Header from '../components/Header'
import ShowList from './ShowList'
import Theme from '../components/Theme'



function App() {
  
  return (
    
    <div>
  <Header />
  <ShowList/>
  <Theme/>


    </div> 
    

)

}
export default App
